const { default: tailwindConfig } = require("tailwindcss/defaultConfig")

module.exports = {
  darkMode: ["class"],
  content: ["app/**/*.{ts,tsx}", "components/**/*.{ts,tsx}", "*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    ...tailwindConfig.theme,
    extend: {
      colors: {
        border: {
          DEFAULT: "hsl(var(--border))",
          dark: "hsl(var(--border-dark))",
        },
        input: {
          DEFAULT: "hsl(var(--input))",
          dark: "hsl(var(--input-dark))",
        },
        ring: {
          DEFAULT: "hsl(var(--ring))",
          dark: "hsl(var(--ring-dark))",
        },
        background: {
          DEFAULT: "hsl(var(--background))",
          dark: "hsl(var(--background-dark))",
        },
        foreground: {
          DEFAULT: "hsl(var(--foreground))",
          dark: "hsl(var(--foreground-dark))",
        },
        primary: {
          DEFAULT: "#16a34a", // Vibrant green matching the recycling symbol
          foreground: "#ffffff",
          50: "#f0fdf4",
          100: "#dcfce7",
          200: "#bbf7d0",
          300: "#86efac",
          400: "#4ade80",
          500: "#22c55e",
          600: "#16a34a", // Main vibrant green
          700: "#15803d",
          800: "#166534",
          900: "#14532d",
          950: "#052e16",
          // Dark mode variants
          dark: {
            DEFAULT: "#22c55e", // Brighter in dark mode for contrast
            foreground: "#000000",
            50: "#052e16",
            100: "#14532d",
            200: "#166534",
            300: "#15803d",
            400: "#16a34a",
            500: "#22c55e",
            600: "#4ade80", // Main vibrant green in dark mode
            700: "#86efac",
            800: "#bbf7d0",
            900: "#dcfce7",
            950: "#f0fdf4",
          },
        },
        secondary: {
          DEFAULT: "#64748b", // Blue-gray from logo background
          foreground: "#ffffff",
          50: "#f8fafc",
          100: "#f1f5f9",
          200: "#e2e8f0",
          300: "#cbd5e1",
          400: "#94a3b8",
          500: "#64748b", // Main blue-gray
          600: "#475569",
          700: "#334155",
          800: "#1e293b",
          900: "#0f172a",
          // Dark mode variants
          dark: {
            DEFAULT: "#94a3b8", // Lighter in dark mode for contrast
            foreground: "#000000",
            50: "#0f172a",
            100: "#1e293b",
            200: "#334155",
            300: "#475569",
            400: "#64748b",
            500: "#94a3b8", // Main blue-gray in dark mode
            600: "#cbd5e1",
            700: "#e2e8f0",
            800: "#f1f5f9",
            900: "#f8fafc",
          },
        },
        accent: {
          DEFAULT: "#10b981", // Emerald accent
          foreground: "#ffffff",
          50: "#ecfdf5",
          100: "#d1fae5",
          200: "#a7f3d0",
          300: "#6ee7b7",
          400: "#34d399",
          500: "#10b981",
          600: "#059669",
          700: "#047857",
          800: "#065f46",
          900: "#064e3b",
          // Dark mode variants
          dark: {
            DEFAULT: "#34d399", // Brighter in dark mode for contrast
            foreground: "#000000",
            50: "#064e3b",
            100: "#065f46",
            200: "#047857",
            300: "#059669",
            400: "#10b981",
            500: "#34d399", // Main accent in dark mode
            600: "#6ee7b7",
            700: "#a7f3d0",
            800: "#d1fae5",
            900: "#ecfdf5",
          },
        },
        metallic: {
          DEFAULT: "#e2e8f0", // Metallic silver
          foreground: "#334155",
          light: "#f8fafc",
          dark: "#cbd5e1",
          // Dark mode variants
          darkMode: {
            DEFAULT: "#475569", // Darker metallic for dark mode
            foreground: "#e2e8f0",
            light: "#334155",
            dark: "#1e293b",
          },
        },
        destructive: {
          DEFAULT: "#ef4444",
          foreground: "#ffffff",
          dark: {
            DEFAULT: "#f87171",
            foreground: "#000000",
          },
        },
        muted: {
          DEFAULT: "#f1f5f9",
          foreground: "#64748b",
          dark: {
            DEFAULT: "#1e293b",
            foreground: "#94a3b8",
          },
        },
        popover: {
          DEFAULT: "#ffffff",
          foreground: "#0f172a",
          dark: {
            DEFAULT: "#0f172a",
            foreground: "#f8fafc",
          },
        },
        card: {
          DEFAULT: "#ffffff",
          foreground: "#0f172a",
          dark: {
            DEFAULT: "#1e293b",
            foreground: "#f8fafc",
          },
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      backgroundImage: {
        "gradient-eco": "linear-gradient(135deg, #16a34a 0%, #10b981 50%, #059669 100%)",
        "gradient-metallic": "linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #cbd5e1 100%)",
        "gradient-blue-gray": "linear-gradient(135deg, #64748b 0%, #475569 50%, #334155 100%)",
        // Dark mode gradients
        "gradient-eco-dark": "linear-gradient(135deg, #22c55e 0%, #34d399 50%, #10b981 100%)",
        "gradient-metallic-dark": "linear-gradient(135deg, #334155 0%, #1e293b 50%, #0f172a 100%)",
        "gradient-blue-gray-dark": "linear-gradient(135deg, #94a3b8 0%, #64748b 50%, #475569 100%)",
      },
      boxShadow: {
        eco: "0 4px 14px 0 rgba(22, 163, 74, 0.15)",
        metallic: "0 4px 14px 0 rgba(100, 116, 139, 0.15)",
        // Dark mode shadows
        "eco-dark": "0 4px 14px 0 rgba(34, 197, 94, 0.25)",
        "metallic-dark": "0 4px 14px 0 rgba(15, 23, 42, 0.5)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
