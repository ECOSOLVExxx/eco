"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type BookingStatus = "scheduled" | "completed" | "cancelled"

export type Booking = {
  id: string
  serviceType: "onsite" | "offsite" | "harddrive"
  date: string
  timeSlot: string
  status: BookingStatus
  address: {
    street: string
    city: string
    state: string
    zipCode: string
  }
  estimatedVolume: string
  isRecurring: boolean
  frequency?: string
  specialInstructions?: string
  createdAt: string
}

type BookingContextType = {
  bookings: Booking[]
  getBooking: (id: string) => Booking | undefined
  cancelBooking: (id: string) => void
  rescheduleBooking: (id: string, date: string, timeSlot: string) => void
}

// Mock booking data
const mockBookings: Booking[] = [
  {
    id: "booking-1",
    serviceType: "onsite",
    date: "2025-06-15",
    timeSlot: "10:00 AM - 12:00 PM",
    status: "scheduled",
    address: {
      street: "123 Business Ave",
      city: "Eco City",
      state: "EC",
      zipCode: "12345",
    },
    estimatedVolume: "6-15 boxes",
    isRecurring: true,
    frequency: "monthly",
    createdAt: "2025-05-28",
  },
  {
    id: "booking-2",
    serviceType: "harddrive",
    date: "2025-06-05",
    timeSlot: "2:00 PM - 4:00 PM",
    status: "scheduled",
    address: {
      street: "456 Corporate Blvd",
      city: "Eco City",
      state: "EC",
      zipCode: "12345",
    },
    estimatedVolume: "1-5 boxes",
    isRecurring: false,
    specialInstructions: "Please bring certificate of destruction",
    createdAt: "2025-05-25",
  },
  {
    id: "booking-3",
    serviceType: "offsite",
    date: "2025-05-20",
    timeSlot: "8:00 AM - 10:00 AM",
    status: "completed",
    address: {
      street: "789 Main St",
      city: "Eco City",
      state: "EC",
      zipCode: "12345",
    },
    estimatedVolume: "16-30 boxes",
    isRecurring: false,
    createdAt: "2025-05-10",
  },
  {
    id: "booking-4",
    serviceType: "onsite",
    date: "2025-05-15",
    timeSlot: "12:00 PM - 2:00 PM",
    status: "cancelled",
    address: {
      street: "123 Business Ave",
      city: "Eco City",
      state: "EC",
      zipCode: "12345",
    },
    estimatedVolume: "6-15 boxes",
    isRecurring: false,
    createdAt: "2025-05-05",
  },
]

const BookingContext = createContext<BookingContextType | undefined>(undefined)

export function BookingProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>(mockBookings)

  const getBooking = (id: string) => {
    return bookings.find((booking) => booking.id === id)
  }

  const cancelBooking = (id: string) => {
    setBookings(
      bookings.map((booking) => (booking.id === id ? { ...booking, status: "cancelled" as BookingStatus } : booking)),
    )
  }

  const rescheduleBooking = (id: string, date: string, timeSlot: string) => {
    setBookings(bookings.map((booking) => (booking.id === id ? { ...booking, date, timeSlot } : booking)))
  }

  return (
    <BookingContext.Provider value={{ bookings, getBooking, cancelBooking, rescheduleBooking }}>
      {children}
    </BookingContext.Provider>
  )
}

export function useBookings() {
  const context = useContext(BookingContext)
  if (context === undefined) {
    throw new Error("useBookings must be used within a BookingProvider")
  }
  return context
}
