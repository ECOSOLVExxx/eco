"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Calendar, Clock, FileText, AlertTriangle, CheckCircle, ArrowRight } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/auth-context"
import { useBookings } from "@/contexts/booking-context"

export default function DashboardPage() {
  const { user } = useAuth()
  const { bookings } = useBookings()
  const [stats, setStats] = useState({
    upcoming: 0,
    completed: 0,
    cancelled: 0,
    nextBooking: null as string | null,
  })

  useEffect(() => {
    // Calculate dashboard stats
    const upcoming = bookings.filter((b) => b.status === "scheduled").length
    const completed = bookings.filter((b) => b.status === "completed").length
    const cancelled = bookings.filter((b) => b.status === "cancelled").length

    // Find next booking date
    const upcomingBookings = bookings
      .filter((b) => b.status === "scheduled")
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    const nextBooking = upcomingBookings.length > 0 ? upcomingBookings[0].date : null

    setStats({ upcoming, completed, cancelled, nextBooking })
  }, [bookings])

  // Get recent bookings (last 3)
  const recentBookings = [...bookings]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3)

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Welcome back, {user?.firstName}!</h1>
          <p className="text-gray-500">Here's an overview of your shredding services.</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button className="bg-primary-600 hover:bg-primary-700" asChild>
            <Link href="/dashboard/bookings/new">Schedule New Pickup</Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Upcoming Pickups</CardTitle>
              <Calendar className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.upcoming}</div>
              {stats.nextBooking && (
                <p className="text-xs text-gray-500">Next pickup: {new Date(stats.nextBooking).toLocaleDateString()}</p>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Completed Pickups</CardTitle>
              <CheckCircle className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.completed}</div>
              <p className="text-xs text-gray-500">All time</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Cancelled Pickups</CardTitle>
              <AlertTriangle className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.cancelled}</div>
              <p className="text-xs text-gray-500">All time</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Bookings */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium">Recent Bookings</h2>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard/bookings" className="flex items-center">
              View all
              <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="space-y-4">
          {recentBookings.map((booking) => (
            <Card key={booking.id}>
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex items-start space-x-4">
                    <div
                      className={`mt-0.5 rounded-full p-1.5 ${
                        booking.status === "scheduled"
                          ? "bg-blue-100"
                          : booking.status === "completed"
                            ? "bg-green-100"
                            : "bg-red-100"
                      }`}
                    >
                      {booking.status === "scheduled" ? (
                        <Clock className="h-4 w-4 text-blue-600" />
                      ) : booking.status === "completed" ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium">
                        {booking.serviceType === "onsite"
                          ? "On-Site Shredding"
                          : booking.serviceType === "offsite"
                            ? "Off-Site Shredding"
                            : "Hard Drive Destruction"}
                      </div>
                      <div className="text-sm text-gray-500">
                        {booking.address.city}, {booking.address.state}
                      </div>
                    </div>
                  </div>
                  <div className="mt-2 md:mt-0 flex flex-col md:items-end">
                    <div className="text-sm font-medium">
                      {new Date(booking.date).toLocaleDateString()} • {booking.timeSlot}
                    </div>
                    <div
                      className={`text-xs ${
                        booking.status === "scheduled"
                          ? "text-blue-600"
                          : booking.status === "completed"
                            ? "text-green-600"
                            : "text-red-600"
                      }`}
                    >
                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t px-4 py-2.5">
                <Button variant="ghost" size="sm" asChild className="ml-auto">
                  <Link href={`/dashboard/bookings/${booking.id}`}>View Details</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}

          {recentBookings.length === 0 && (
            <Card>
              <CardContent className="p-6 text-center">
                <FileText className="mx-auto h-8 w-8 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No bookings yet</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by scheduling your first pickup.</p>
                <div className="mt-4">
                  <Button className="bg-primary-600 hover:bg-primary-700" asChild>
                    <Link href="/dashboard/bookings/new">Schedule Pickup</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
