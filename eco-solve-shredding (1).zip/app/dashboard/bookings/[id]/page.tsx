"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  Calendar,
  Clock,
  MapPin,
  Package,
  FileText,
  ArrowLeft,
  Pencil,
  XCircle,
  CheckCircle,
  AlertTriangle,
  Printer,
  Phone,
  Mail,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useBookings } from "@/contexts/booking-context"
import { Badge } from "@/components/ui/badge"

export default function BookingDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { getBooking, cancelBooking } = useBookings()
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const booking = getBooking(params.id)

  if (!booking) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Booking Not Found</h2>
        <p className="text-gray-500 mb-6">The booking you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/dashboard/bookings">Back to Bookings</Link>
        </Button>
      </div>
    )
  }

  const handleCancelBooking = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    cancelBooking(booking.id)
    setIsLoading(false)
    setIsCancelDialogOpen(false)
  }

  const getStatusColor = () => {
    switch (booking.status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = () => {
    switch (booking.status) {
      case "scheduled":
        return <Clock className="h-5 w-5 text-blue-600" />
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "cancelled":
        return <XCircle className="h-5 w-5 text-red-600" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-2xl font-bold tracking-tight">Booking Details</h1>
          <Badge className={getStatusColor()}>{booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}</Badge>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          {booking.status === "scheduled" && (
            <>
              <Button variant="outline" size="sm" asChild>
                <Link href={`/dashboard/bookings/${booking.id}/edit`}>
                  <Pencil className="h-4 w-4 mr-2" />
                  Reschedule
                </Link>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="text-red-600 border-red-200 hover:bg-red-50"
                onClick={() => setIsCancelDialogOpen(true)}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Main Booking Info */}
        <div className="md:col-span-2 space-y-6">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-2">
                  {getStatusIcon()}
                  <CardTitle>
                    {booking.serviceType === "onsite"
                      ? "On-Site Shredding"
                      : booking.serviceType === "offsite"
                        ? "Off-Site Shredding"
                        : "Hard Drive Destruction"}
                  </CardTitle>
                </div>
                <CardDescription>Created on {new Date(booking.createdAt).toLocaleDateString()}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Date</div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                      {new Date(booking.date).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Time</div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-500" />
                      {booking.timeSlot}
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-sm font-medium text-gray-500">Address</div>
                  <div className="flex items-start">
                    <MapPin className="h-4 w-4 mr-2 text-gray-500 mt-0.5" />
                    <div>
                      {booking.address.street}
                      <br />
                      {booking.address.city}, {booking.address.state} {booking.address.zipCode}
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Estimated Volume</div>
                    <div className="flex items-center">
                      <Package className="h-4 w-4 mr-2 text-gray-500" />
                      {booking.estimatedVolume}
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Service Type</div>
                    <div>
                      {booking.serviceType === "onsite"
                        ? "On-Site Shredding"
                        : booking.serviceType === "offsite"
                          ? "Off-Site Shredding"
                          : "Hard Drive Destruction"}
                    </div>
                  </div>
                </div>

                {booking.isRecurring && (
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Recurring Service</div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                      {booking.frequency?.charAt(0).toUpperCase() + booking.frequency?.slice(1)}
                    </div>
                  </div>
                )}

                {booking.specialInstructions && (
                  <div className="space-y-1">
                    <div className="text-sm font-medium text-gray-500">Special Instructions</div>
                    <div className="flex items-start">
                      <FileText className="h-4 w-4 mr-2 text-gray-500 mt-0.5" />
                      {booking.specialInstructions}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {booking.status === "completed" && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Certificate of Destruction
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Destruction Verified</h3>
                    <p className="text-gray-500 mb-4">
                      Your materials were securely destroyed on {new Date(booking.date).toLocaleDateString()} in
                      accordance with all applicable regulations.
                    </p>
                    <Button>Download Certificate</Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Need Help?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-500">
                  If you have any questions about your booking or need to make changes, our customer service team is
                  here to help.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center text-sm">
                    <Phone className="h-4 w-4 mr-2 text-gray-500" />
                    (555) 123-SHRED
                  </div>
                  <div className="flex items-center text-sm">
                    <Mail className="h-4 w-4 mr-2 text-gray-500" />
                    support@ecosolveshredding.com
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Contact Support
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {booking.status === "scheduled" && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preparing for Pickup</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-500">
                    Here are some tips to ensure your shredding service goes smoothly:
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-600 mt-0.5" />
                      Ensure all materials are accessible
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-600 mt-0.5" />
                      Remove paper clips and large binders
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-4 w-4 mr-2 text-green-600 mt-0.5" />
                      Have a representative available to verify service
                    </li>
                  </ul>
                  <Button variant="outline" className="w-full">
                    View Preparation Guide
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>

      {/* Cancel Dialog */}
      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Are you sure you want to cancel this booking? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCancelDialogOpen(false)}>
              Keep Booking
            </Button>
            <Button variant="destructive" onClick={handleCancelBooking} disabled={isLoading}>
              {isLoading ? "Cancelling..." : "Yes, Cancel Booking"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
