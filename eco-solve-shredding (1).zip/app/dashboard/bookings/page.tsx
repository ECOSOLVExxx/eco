"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Calendar, Clock, CheckCircle, AlertTriangle, Filter, Search, Plus } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useBookings, type BookingStatus } from "@/contexts/booking-context"

export default function BookingsPage() {
  const { bookings } = useBookings()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<BookingStatus | "all">("all")

  // Filter bookings based on search term and status
  const filteredBookings = bookings.filter((booking) => {
    const matchesSearch =
      searchTerm === "" ||
      booking.address.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.address.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.serviceType.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || booking.status === statusFilter

    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Bookings</h1>
          <p className="text-gray-500">View and manage all your shredding service appointments.</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button className="bg-primary-600 hover:bg-primary-700" asChild>
            <Link href="/dashboard/bookings/new">
              <Plus className="mr-2 h-4 w-4" /> New Booking
            </Link>
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search by location or service type..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="w-full sm:w-48">
          <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as BookingStatus | "all")}>
            <SelectTrigger>
              <div className="flex items-center">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Filter by status" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Bookings List */}
      <div className="space-y-4">
        {filteredBookings.map((booking, index) => (
          <motion.div
            key={booking.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Link href={`/dashboard/bookings/${booking.id}`}>
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`mt-0.5 rounded-full p-1.5 ${
                          booking.status === "scheduled"
                            ? "bg-blue-100"
                            : booking.status === "completed"
                              ? "bg-green-100"
                              : "bg-red-100"
                        }`}
                      >
                        {booking.status === "scheduled" ? (
                          <Clock className="h-4 w-4 text-blue-600" />
                        ) : booking.status === "completed" ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">
                          {booking.serviceType === "onsite"
                            ? "On-Site Shredding"
                            : booking.serviceType === "offsite"
                              ? "Off-Site Shredding"
                              : "Hard Drive Destruction"}
                        </div>
                        <div className="text-sm text-gray-500">
                          {booking.address.street}, {booking.address.city}, {booking.address.state}{" "}
                          {booking.address.zipCode}
                        </div>
                      </div>
                    </div>
                    <div className="mt-2 md:mt-0 flex flex-col md:items-end">
                      <div className="flex items-center text-sm font-medium">
                        <Calendar className="mr-1 h-4 w-4 text-gray-500" />
                        {new Date(booking.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="mr-1 h-4 w-4" />
                        {booking.timeSlot}
                      </div>
                      <div
                        className={`mt-1 text-xs px-2 py-0.5 rounded-full ${
                          booking.status === "scheduled"
                            ? "bg-blue-100 text-blue-800"
                            : booking.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                        }`}
                      >
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        ))}

        {filteredBookings.length === 0 && (
          <Card>
            <CardContent className="p-6 text-center">
              <Calendar className="mx-auto h-8 w-8 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No bookings found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchTerm || statusFilter !== "all"
                  ? "Try adjusting your search or filter criteria."
                  : "Get started by scheduling your first pickup."}
              </p>
              {!searchTerm && statusFilter === "all" && (
                <div className="mt-4">
                  <Button className="bg-primary-600 hover:bg-primary-700" asChild>
                    <Link href="/dashboard/bookings/new">Schedule Pickup</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
