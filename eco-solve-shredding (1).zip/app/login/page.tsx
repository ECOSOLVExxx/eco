"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/contexts/auth-context"
import { ThemeToggle } from "@/components/theme-toggle"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      const success = await login(email, password)
      if (success) {
        router.push("/dashboard")
      } else {
        setError("Invalid email or password")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-metallic-light to-primary-50 dark:from-secondary-dark-100 dark:to-secondary-dark-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Link href="/" className="inline-flex items-center space-x-3">
              <img
                src="/images/ecosolve-logo.jpg"
                alt="EcoSolve"
                className="h-10 w-10 rounded-full shadow-eco dark:shadow-eco-dark"
              />
              <span className="text-2xl font-bold bg-gradient-eco dark:bg-gradient-eco-dark bg-clip-text text-transparent">
                EcoSolve
              </span>
            </Link>
            <div className="ml-4">
              <ThemeToggle />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-secondary-900 dark:text-secondary-dark-900">
            Sign in to your account
          </h2>
          <p className="mt-2 text-sm text-secondary-600 dark:text-secondary-dark-600">
            Or{" "}
            <Link
              href="/signup"
              className="font-medium text-primary-600 dark:text-primary-dark-600 hover:text-primary-500 dark:hover:text-primary-dark-500"
            >
              create a new account
            </Link>
          </p>
        </div>

        <Card className="dark:bg-secondary-dark-200 dark:border-secondary-dark-300 shadow-eco dark:shadow-eco-dark">
          <CardHeader>
            <CardTitle className="text-secondary-800 dark:text-secondary-dark-800">Customer Portal Login</CardTitle>
            <CardDescription className="text-secondary-600 dark:text-secondary-dark-600">
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div className="space-y-1">
                <Label htmlFor="email" className="text-secondary-700 dark:text-secondary-dark-700">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="you@example.com"
                  className="border-2 border-primary-200 focus:border-primary-500 dark:border-primary-dark-300 dark:focus:border-primary-dark-500 dark:bg-secondary-dark-100"
                />
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-secondary-700 dark:text-secondary-dark-700">
                    Password
                  </Label>
                  <Link
                    href="/forgot-password"
                    className="text-sm font-medium text-primary-600 dark:text-primary-dark-600 hover:text-primary-500 dark:hover:text-primary-dark-500"
                  >
                    Forgot your password?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="border-2 border-primary-200 focus:border-primary-500 dark:border-primary-dark-300 dark:focus:border-primary-dark-500 dark:bg-secondary-dark-100"
                />
              </div>
              <div className="text-sm text-secondary-500 dark:text-secondary-dark-500">Demo</div>
            </CardContent>
          </form>
        </Card>
      </div>
    </div>
  )
}
