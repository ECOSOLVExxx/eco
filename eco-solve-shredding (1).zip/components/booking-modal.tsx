"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Calendar, Clock, MapPin, Package, X, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
}

interface BookingData {
  date: Date | null
  timeSlot: string
  serviceType: string
  estimatedVolume: string
  contactInfo: {
    firstName: string
    lastName: string
    email: string
    phone: string
    company: string
  }
  address: {
    street: string
    city: string
    state: string
    zipCode: string
  }
  specialInstructions: string
  isRecurring: boolean
  frequency: string
}

const timeSlots = [
  "8:00 AM - 10:00 AM",
  "10:00 AM - 12:00 PM",
  "12:00 PM - 2:00 PM",
  "2:00 PM - 4:00 PM",
  "4:00 PM - 6:00 PM",
]

const serviceTypes = [
  { value: "onsite", label: "On-Site Shredding", description: "We shred at your location" },
  { value: "offsite", label: "Off-Site Shredding", description: "Secure pickup and facility shredding" },
  { value: "harddrive", label: "Hard Drive Destruction", description: "Electronic media destruction" },
]

const volumeOptions = ["1-5 boxes", "6-15 boxes", "16-30 boxes", "31+ boxes", "Bulk/Warehouse cleanout"]

export function BookingModal({ isOpen, onClose }: BookingModalProps) {
  const [step, setStep] = useState(1)
  const [bookingData, setBookingData] = useState<BookingData>({
    date: null,
    timeSlot: "",
    serviceType: "",
    estimatedVolume: "",
    contactInfo: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      company: "",
    },
    address: {
      street: "",
      city: "",
      state: "",
      zipCode: "",
    },
    specialInstructions: "",
    isRecurring: false,
    frequency: "",
  })

  const [selectedDate, setSelectedDate] = useState(new Date())
  const [currentMonth, setCurrentMonth] = useState(new Date())

  const resetForm = () => {
    setStep(1)
    setBookingData({
      date: null,
      timeSlot: "",
      serviceType: "",
      estimatedVolume: "",
      contactInfo: {
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        company: "",
      },
      address: {
        street: "",
        city: "",
        state: "",
        zipCode: "",
      },
      specialInstructions: "",
      isRecurring: false,
      frequency: "",
    })
  }

  const handleClose = () => {
    resetForm()
    onClose()
  }

  const nextStep = () => setStep(step + 1)
  const prevStep = () => setStep(step - 1)

  const isStepValid = () => {
    switch (step) {
      case 1:
        return bookingData.serviceType && bookingData.estimatedVolume
      case 2:
        return bookingData.date && bookingData.timeSlot
      case 3:
        return (
          bookingData.contactInfo.firstName &&
          bookingData.contactInfo.lastName &&
          bookingData.contactInfo.email &&
          bookingData.contactInfo.phone &&
          bookingData.address.street &&
          bookingData.address.city &&
          bookingData.address.state &&
          bookingData.address.zipCode
        )
      default:
        return true
    }
  }

  const generateCalendar = () => {
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startDate = new Date(firstDay)
    startDate.setDate(startDate.getDate() - firstDay.getDay())

    const days = []
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate)
      date.setDate(startDate.getDate() + i)

      const isCurrentMonth = date.getMonth() === month
      const isToday = date.getTime() === today.getTime()
      const isPast = date < today
      const isSelected = bookingData.date && date.getTime() === bookingData.date.getTime()
      const isWeekend = date.getDay() === 0 || date.getDay() === 6

      days.push({
        date,
        isCurrentMonth,
        isToday,
        isPast,
        isSelected,
        isWeekend,
        isDisabled: isPast || isWeekend,
      })
    }

    return days
  }

  const handleDateSelect = (date: Date) => {
    if (date < new Date() || date.getDay() === 0 || date.getDay() === 6) return
    setBookingData({ ...bookingData, date })
  }

  const handleSubmit = () => {
    // In a real app, this would submit to your backend
    console.log("Booking submitted:", bookingData)
    setStep(5) // Confirmation step
  }

  const stepTitles = ["Service Details", "Schedule", "Contact Information", "Review & Confirm", "Confirmation"]

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Schedule Pickup - {stepTitles[step - 1]}</span>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {/* Progress Bar */}
        <div className="flex items-center space-x-2 mb-6">
          {[1, 2, 3, 4].map((stepNumber) => (
            <div key={stepNumber} className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step >= stepNumber ? "bg-primary-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                {stepNumber}
              </div>
              {stepNumber < 4 && <div className={`w-12 h-1 ${step > stepNumber ? "bg-primary-600" : "bg-gray-200"}`} />}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Step 1: Service Details */}
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <Label className="text-base font-medium mb-4 block">Select Service Type</Label>
                  <div className="grid gap-4">
                    {serviceTypes.map((service) => (
                      <Card
                        key={service.value}
                        className={`cursor-pointer transition-all ${
                          bookingData.serviceType === service.value
                            ? "ring-2 ring-primary-600 bg-primary-50"
                            : "hover:shadow-md"
                        }`}
                        onClick={() => setBookingData({ ...bookingData, serviceType: service.value })}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-4 h-4 rounded-full border-2 ${
                                bookingData.serviceType === service.value
                                  ? "bg-primary-600 border-primary-600"
                                  : "border-gray-300"
                              }`}
                            />
                            <div>
                              <h3 className="font-medium">{service.label}</h3>
                              <p className="text-sm text-gray-600">{service.description}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="volume" className="text-base font-medium">
                    Estimated Volume
                  </Label>
                  <Select
                    value={bookingData.estimatedVolume}
                    onValueChange={(value) => setBookingData({ ...bookingData, estimatedVolume: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select estimated volume" />
                    </SelectTrigger>
                    <SelectContent>
                      {volumeOptions.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {/* Step 2: Schedule */}
            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <Label className="text-base font-medium mb-4 block">Select Date</Label>
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newMonth = new Date(currentMonth)
                            newMonth.setMonth(currentMonth.getMonth() - 1)
                            setCurrentMonth(newMonth)
                          }}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <h3 className="font-medium">
                          {currentMonth.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                        </h3>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newMonth = new Date(currentMonth)
                            newMonth.setMonth(currentMonth.getMonth() + 1)
                            setCurrentMonth(newMonth)
                          }}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-7 gap-1 mb-2">
                        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                          <div key={day} className="p-2 text-center text-sm font-medium text-gray-600">
                            {day}
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-7 gap-1">
                        {generateCalendar().map((day, index) => (
                          <button
                            key={index}
                            onClick={() => handleDateSelect(day.date)}
                            disabled={day.isDisabled}
                            className={`p-2 text-sm rounded-md transition-colors ${
                              day.isSelected
                                ? "bg-primary-600 text-white"
                                : day.isToday
                                  ? "bg-primary-100 text-primary-700"
                                  : day.isCurrentMonth && !day.isDisabled
                                    ? "hover:bg-gray-100"
                                    : ""
                            } ${
                              day.isDisabled
                                ? "text-gray-300 cursor-not-allowed"
                                : day.isCurrentMonth
                                  ? "text-gray-900"
                                  : "text-gray-400"
                            }`}
                          >
                            {day.date.getDate()}
                          </button>
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mt-2">* Weekends are not available for pickup</p>
                    </CardContent>
                  </Card>
                </div>

                {bookingData.date && (
                  <div>
                    <Label className="text-base font-medium mb-4 block">Select Time Slot</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {timeSlots.map((slot) => (
                        <Card
                          key={slot}
                          className={`cursor-pointer transition-all ${
                            bookingData.timeSlot === slot ? "ring-2 ring-primary-600 bg-primary-50" : "hover:shadow-md"
                          }`}
                          onClick={() => setBookingData({ ...bookingData, timeSlot: slot })}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-center space-x-3">
                              <Clock className="h-4 w-4 text-gray-600" />
                              <span className="font-medium">{slot}</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Contact Information */}
            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Contact Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={bookingData.contactInfo.firstName}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            contactInfo: { ...bookingData.contactInfo, firstName: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={bookingData.contactInfo.lastName}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            contactInfo: { ...bookingData.contactInfo, lastName: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={bookingData.contactInfo.email}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            contactInfo: { ...bookingData.contactInfo, email: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={bookingData.contactInfo.phone}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            contactInfo: { ...bookingData.contactInfo, phone: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div className="md:col-span-2">
                      <Label htmlFor="company">Company (Optional)</Label>
                      <Input
                        id="company"
                        value={bookingData.contactInfo.company}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            contactInfo: { ...bookingData.contactInfo, company: e.target.value },
                          })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Pickup Address</h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="street">Street Address *</Label>
                      <Input
                        id="street"
                        value={bookingData.address.street}
                        onChange={(e) =>
                          setBookingData({
                            ...bookingData,
                            address: { ...bookingData.address, street: e.target.value },
                          })
                        }
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="city">City *</Label>
                        <Input
                          id="city"
                          value={bookingData.address.city}
                          onChange={(e) =>
                            setBookingData({
                              ...bookingData,
                              address: { ...bookingData.address, city: e.target.value },
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="state">State *</Label>
                        <Input
                          id="state"
                          value={bookingData.address.state}
                          onChange={(e) =>
                            setBookingData({
                              ...bookingData,
                              address: { ...bookingData.address, state: e.target.value },
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label htmlFor="zipCode">ZIP Code *</Label>
                        <Input
                          id="zipCode"
                          value={bookingData.address.zipCode}
                          onChange={(e) =>
                            setBookingData({
                              ...bookingData,
                              address: { ...bookingData.address, zipCode: e.target.value },
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="instructions">Special Instructions</Label>
                  <Textarea
                    id="instructions"
                    placeholder="Any special instructions for pickup (building access, parking, etc.)"
                    value={bookingData.specialInstructions}
                    onChange={(e) => setBookingData({ ...bookingData, specialInstructions: e.target.value })}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="recurring"
                    checked={bookingData.isRecurring}
                    onCheckedChange={(checked) => setBookingData({ ...bookingData, isRecurring: checked as boolean })}
                  />
                  <Label htmlFor="recurring">This is a recurring service</Label>
                </div>

                {bookingData.isRecurring && (
                  <div>
                    <Label htmlFor="frequency">Frequency</Label>
                    <Select
                      value={bookingData.frequency}
                      onValueChange={(value) => setBookingData({ ...bookingData, frequency: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="biweekly">Bi-weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            )}

            {/* Step 4: Review & Confirm */}
            {step === 4 && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium">Review Your Booking</h3>

                <div className="grid gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Package className="h-5 w-5" />
                        <span>Service Details</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p>
                          <strong>Service:</strong>{" "}
                          {serviceTypes.find((s) => s.value === bookingData.serviceType)?.label}
                        </p>
                        <p>
                          <strong>Volume:</strong> {bookingData.estimatedVolume}
                        </p>
                        {bookingData.isRecurring && (
                          <p>
                            <strong>Frequency:</strong> {bookingData.frequency}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Calendar className="h-5 w-5" />
                        <span>Schedule</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p>
                          <strong>Date:</strong> {bookingData.date?.toLocaleDateString()}
                        </p>
                        <p>
                          <strong>Time:</strong> {bookingData.timeSlot}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <MapPin className="h-5 w-5" />
                        <span>Contact & Address</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p>
                          <strong>Name:</strong> {bookingData.contactInfo.firstName} {bookingData.contactInfo.lastName}
                        </p>
                        {bookingData.contactInfo.company && (
                          <p>
                            <strong>Company:</strong> {bookingData.contactInfo.company}
                          </p>
                        )}
                        <p>
                          <strong>Email:</strong> {bookingData.contactInfo.email}
                        </p>
                        <p>
                          <strong>Phone:</strong> {bookingData.contactInfo.phone}
                        </p>
                        <p>
                          <strong>Address:</strong> {bookingData.address.street}, {bookingData.address.city},{" "}
                          {bookingData.address.state} {bookingData.address.zipCode}
                        </p>
                        {bookingData.specialInstructions && (
                          <p>
                            <strong>Special Instructions:</strong> {bookingData.specialInstructions}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Step 5: Confirmation */}
            {step === 5 && (
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h3>
                  <p className="text-gray-600 mb-4">
                    Your pickup has been scheduled for {bookingData.date?.toLocaleDateString()} at{" "}
                    {bookingData.timeSlot}
                  </p>
                  <p className="text-sm text-gray-500">
                    You will receive a confirmation email shortly with all the details and our contact information.
                  </p>
                </div>
                <Button onClick={handleClose} className="bg-primary-600 hover:bg-primary-700">
                  Close
                </Button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Buttons */}
        {step < 5 && (
          <div className="flex justify-between pt-6 border-t">
            <Button variant="outline" onClick={prevStep} disabled={step === 1}>
              Previous
            </Button>
            <Button
              onClick={step === 4 ? handleSubmit : nextStep}
              disabled={!isStepValid()}
              className="bg-primary-600 hover:bg-primary-700"
            >
              {step === 4 ? "Confirm Booking" : "Next"}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
